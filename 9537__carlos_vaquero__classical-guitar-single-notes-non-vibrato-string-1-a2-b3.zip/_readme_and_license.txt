Pack downloaded from Freesound
----------------------------------------

"Classical Guitar: Single notes Non Vibrato String 1: A2-B3"

This Pack of sounds contains sounds by the following user:
 - Carlos_Vaquero ( https://freesound.org/people/Carlos_Vaquero/ )

You can find this pack online at: https://freesound.org/people/Carlos_Vaquero/packs/9537/


Licenses in this Pack (see below for individual sound licenses)
---------------------------------------------------------------

Attribution NonCommercial 4.0: https://creativecommons.org/licenses/by-nc/4.0/


Sounds in this Pack
-------------------

  * 154016__carlos_vaquero__classical-guitar-b-3-plucked-non-vibrato.wav.wav
    * url: https://freesound.org/s/154016/
    * license: Attribution NonCommercial 4.0
  * 154015__carlos_vaquero__classical-guitar-a-3-plucked-non-vibrato.wav.wav
    * url: https://freesound.org/s/154015/
    * license: Attribution NonCommercial 4.0
  * 154014__carlos_vaquero__classical-guitar-a-3-plucked-non-vibrato.wav.wav
    * url: https://freesound.org/s/154014/
    * license: Attribution NonCommercial 4.0
  * 154013__carlos_vaquero__classical-guitar-g-3-plucked-non-vibrato.wav.wav
    * url: https://freesound.org/s/154013/
    * license: Attribution NonCommercial 4.0
  * 154012__carlos_vaquero__classical-guitar-g-3-plucked-non-vibrato.wav.wav
    * url: https://freesound.org/s/154012/
    * license: Attribution NonCommercial 4.0
  * 154011__carlos_vaquero__classical-guitar-f-3-plucked-non-vibrato.wav.wav
    * url: https://freesound.org/s/154011/
    * license: Attribution NonCommercial 4.0
  * 154010__carlos_vaquero__classical-guitar-f-3-plucked-non-vibrato.wav.wav
    * url: https://freesound.org/s/154010/
    * license: Attribution NonCommercial 4.0
  * 154009__carlos_vaquero__classical-guitar-e-3-plucked-non-vibrato.wav.wav
    * url: https://freesound.org/s/154009/
    * license: Attribution NonCommercial 4.0
  * 154008__carlos_vaquero__classical-guitar-d-3-plucked-non-vibrato.wav.wav
    * url: https://freesound.org/s/154008/
    * license: Attribution NonCommercial 4.0
  * 154007__carlos_vaquero__classical-guitar-d-3-plucked-non-vibrato.wav.wav
    * url: https://freesound.org/s/154007/
    * license: Attribution NonCommercial 4.0
  * 154006__carlos_vaquero__classical-guitar-c-3-plucked-non-vibrato.wav.wav
    * url: https://freesound.org/s/154006/
    * license: Attribution NonCommercial 4.0
  * 154005__carlos_vaquero__classical-guitar-c-3-plucked-non-vibrato.wav.wav
    * url: https://freesound.org/s/154005/
    * license: Attribution NonCommercial 4.0
  * 154004__carlos_vaquero__classical-guitar-b-2-plucked-non-vibrato.wav.wav
    * url: https://freesound.org/s/154004/
    * license: Attribution NonCommercial 4.0
  * 154003__carlos_vaquero__classical-guitar-a-2-plucked-non-vibrato.wav.wav
    * url: https://freesound.org/s/154003/
    * license: Attribution NonCommercial 4.0
  * 154002__carlos_vaquero__classical-guitar-a-2-plucked-non-vibrato.wav.wav
    * url: https://freesound.org/s/154002/
    * license: Attribution NonCommercial 4.0


